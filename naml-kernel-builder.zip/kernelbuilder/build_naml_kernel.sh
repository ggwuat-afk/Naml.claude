#!/usr/bin/env bash
# build_naml_kernel.sh
#
# Builds a REAL Linux kernel (bzImage) for NAML, from real kernel.org
# source, using kernel/naml_defconfig as the base config. Meant to run on
# a real Linux machine (or WSL on Windows) with internet access -- it
# downloads several hundred MB and needs ~15-60+ minutes and a few GB of
# free disk, depending on your machine.
#
# This has NOT been run end-to-end by whoever wrote this script (no
# internet/kernel-build-toolchain access in that environment) -- read the
# output as it runs, don't assume a silent success.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Override any of these by setting the env var before running, e.g.:
#   KERNEL_VERSION=6.12.107 ./build_naml_kernel.sh
# Check https://kernel.org for the current longterm version if this
# default has gone stale by the time you run it.
KERNEL_VERSION="${KERNEL_VERSION:-6.6.155}"
KERNEL_MAJOR="${KERNEL_VERSION%%.*}"
WORK_DIR="${WORK_DIR:-$SCRIPT_DIR/kernel-build}"
OUT_DIR="${OUT_DIR:-$SCRIPT_DIR/output}"
JOBS="${JOBS:-$(nproc 2>/dev/null || echo 2)}"
SKIP_APT="${SKIP_APT:-0}"

echo "================================================================"
echo " NAML kernel builder"
echo "================================================================"
echo " Kernel version : $KERNEL_VERSION"
echo " Work directory : $WORK_DIR"
echo " Output to      : $OUT_DIR"
echo " Parallel jobs  : $JOBS"
echo "================================================================"
echo

# --- 0. sanity: are we even on Linux? -------------------------------
if [ "$(uname -s)" != "Linux" ]; then
    echo "ERROR: this must run on Linux (a Linux kernel cannot be built"
    echo "with native Windows or macOS toolchains). On Windows, run this"
    echo "through WSL -- use build_naml_kernel.bat, which does that for"
    echo "you, instead of double-clicking this .sh file directly."
    exit 1
fi

# --- 1. build dependencies ------------------------------------------
if [ "$SKIP_APT" != "1" ] && command -v apt-get >/dev/null 2>&1; then
    echo "--- Installing build dependencies via apt (you may be asked for"
    echo "    your sudo password) ---"
    sudo apt-get update
    sudo apt-get install -y \
        build-essential bc bison flex libssl-dev libelf-dev \
        gcc-multilib libc6-dev-i386 wget tar xz-utils patch
    echo
else
    echo "--- Skipping apt (SKIP_APT=1 or apt-get not found). Make sure"
    echo "    these are installed manually before continuing:"
    echo "    make gcc bc bison flex libssl-dev libelf-dev gcc-multilib"
    echo "    libc6-dev-i386 wget tar xz patch"
    echo
fi

for tool in make wget tar patch; do
    command -v "$tool" >/dev/null 2>&1 || {
        echo "ERROR: required tool '$tool' not found. Install it and re-run."
        exit 1
    }
done

mkdir -p "$WORK_DIR" "$OUT_DIR"
cd "$WORK_DIR"

# --- 2. fetch real kernel source from kernel.org ----------------------
TARBALL="linux-${KERNEL_VERSION}.tar.xz"
URL="https://cdn.kernel.org/pub/linux/kernel/v${KERNEL_MAJOR}.x/${TARBALL}"
SRC_DIR="${WORK_DIR}/linux-${KERNEL_VERSION}"

if [ ! -f "$TARBALL" ]; then
    echo "--- Downloading $URL ---"
    wget -O "$TARBALL" "$URL" || {
        echo "ERROR: download failed."
        echo "Check that KERNEL_VERSION=$KERNEL_VERSION is a real release"
        echo "listed at https://kernel.org -- longterm versions drift"
        echo "forward over time and this script's default can go stale."
        exit 1
    }
else
    echo "--- Using already-downloaded $TARBALL ---"
fi

if [ ! -d "$SRC_DIR" ]; then
    echo "--- Extracting (this takes a minute) ---"
    tar xf "$TARBALL"
else
    echo "--- Source already extracted at $SRC_DIR ---"
fi

cd "$SRC_DIR"

# --- 3. apply NAML's kernel patches, best-effort ----------------------
# kernel/patches/*.patch in the NAML repo are explicitly documented
# ("illustrative ... rebase it against the selected kernel version") as
# placeholders, not guaranteed-to-apply patches against any specific
# real kernel tree. So: try each one, dry-run first, skip with a clear
# warning (not a fatal error) on anything that doesn't apply cleanly,
# and keep going -- the kernel still builds and boots without them;
# they are cosmetic (boot banner, quiet boot, etc.), not functionally
# required by anything else in NAML.
PATCH_DIR="$SCRIPT_DIR/patches"
applied=0
skipped=0
if [ -d "$PATCH_DIR" ]; then
    echo
    echo "--- Applying NAML patches from $PATCH_DIR (best-effort) ---"
    for p in "$PATCH_DIR"/*.patch; do
        [ -e "$p" ] || continue
        name="$(basename "$p")"
        if patch -p1 --fuzz=3 --dry-run < "$p" >/tmp/naml_patch_dryrun.log 2>&1; then
            patch -p1 --fuzz=3 < "$p" >/tmp/naml_patch.log 2>&1
            echo "  applied: $name"
            applied=$((applied + 1))
        else
            echo "  SKIPPED: $name (does not apply cleanly against"
            echo "           linux-$KERNEL_VERSION -- this is expected, see"
            echo "           the patch's own header and this project's"
            echo "           README.md; it needs to be rebased by hand"
            echo "           against this exact kernel version if you want it)"
            skipped=$((skipped + 1))
        fi
    done
    echo "Patches applied: $applied, skipped: $skipped"
fi
echo

# --- 4. configure: NAML's defconfig, ported onto this kernel version ---
echo "--- Configuring (ARCH=i386, kernel/naml_defconfig as the base) ---"
cp "$SCRIPT_DIR/naml_defconfig" .config
# olddefconfig fills in anything naml_defconfig doesn't set with this
# kernel version's defaults, and reports (without failing) any option
# naml_defconfig sets that no longer exists in this kernel version --
# watch the output for lines like "... (NEW)" or warnings about unknown
# symbols; some of NAML's legacy CPU-selection options (CONFIG_M686
# etc.) may have moved or been renamed on very new kernels, in which
# case you'll want to pick the closest equivalent in `make menuconfig`
# and re-run from this step.
make ARCH=i386 olddefconfig
echo

# --- 5. build ----------------------------------------------------------
echo "--- Building (this is the slow part: tens of minutes is normal) ---"
make ARCH=i386 -j"$JOBS"

BZIMAGE="arch/x86/boot/bzImage"
if [ ! -f "$BZIMAGE" ]; then
    echo
    echo "=== BUILD DID NOT PRODUCE $BZIMAGE ==="
    echo "Scroll up for the actual compiler/linker error."
    exit 1
fi

OUT_FILE="$OUT_DIR/vmlinuz-naml-${KERNEL_VERSION}"
cp "$BZIMAGE" "$OUT_FILE"
cp .config "$OUT_DIR/config-naml-${KERNEL_VERSION}"

echo
echo "================================================================"
echo " SUCCESS"
echo "================================================================"
echo " Real kernel image: $OUT_FILE"
echo " Config used:       $OUT_DIR/config-naml-${KERNEL_VERSION}"
echo " Patches applied:   $applied   skipped: $skipped"
echo
echo " Next step (not done by this script): turn this bzImage into a"
echo " bootable NAML image together with the userland from the main"
echo " NAML repo -- see that repo's build/mkinitramfs.py and"
echo " build/mkiso.sh (KERNEL=$OUT_FILE ./build/mkiso.sh)."
echo "================================================================"
