@echo off
setlocal

echo ================================================================
echo  NAML kernel builder (Windows launcher)
echo ================================================================
echo.
echo A real Linux kernel cannot be built with native Windows tools --
echo it needs a real Linux environment. This window will build it
echo through WSL (Windows Subsystem for Linux).
echo.

where wsl >nul 2>nul
if errorlevel 1 goto NO_WSL

for /f "usebackq delims=" %%P in (`wsl wslpath -a "%~dp0"`) do set "WSLDIR=%%P"
if "%WSLDIR%"=="" goto NO_WSL

echo Folder (Windows): %~dp0
echo Folder (WSL)    : %WSLDIR%
echo.
echo You may be asked for your Linux (sudo) password the first time, to
echo install build tools (gcc, make, bison, flex, ...). The build itself
echo downloads several hundred MB from kernel.org and can take anywhere
echo from ~15 minutes to well over an hour.
echo.
pause

wsl bash -lc "cd '%WSLDIR%' && chmod +x build_naml_kernel.sh && ./build_naml_kernel.sh"
set "BUILD_RC=%ERRORLEVEL%"

echo.
echo ================================================================
if "%BUILD_RC%"=="0" (
    echo  Build finished. Check the output above -- the real kernel image
    echo  is under the "output" folder next to this file if it succeeded.
) else (
    echo  Build exited with an error ^(code %BUILD_RC%^). Scroll up to see
    echo  what failed.
)
echo ================================================================
echo.
echo Press any key to close this window.
pause >nul
exit /b %BUILD_RC%

:NO_WSL
echo ERROR: WSL (Windows Subsystem for Linux) was not found, or its
echo path translation failed.
echo.
echo Install WSL first, then re-run this file:
echo   1) Open PowerShell AS ADMINISTRATOR
echo   2) Run:   wsl --install
echo   3) Reboot if it asks you to
echo   4) Open "Ubuntu" from the Start menu once, to finish its
echo      first-time setup (it will ask you to create a Linux
echo      username and password -- remember that password, apt will
echo      ask for it again during the actual kernel build)
echo   5) Re-run this file (build_naml_kernel.bat)
echo.
pause
exit /b 1
