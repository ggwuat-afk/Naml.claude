# NAML kernel builder — run this on YOUR machine

This builds a **real** Linux kernel (`bzImage`) for NAML, from real source
downloaded from kernel.org, using `naml_defconfig` as the base
configuration. It needs internet access and real Linux build tools — that
is why it cannot run inside the sandboxed environment this project was
otherwise assembled in, and why you're running it yourself.

## What you get by double-clicking

### On Windows
Double-click **`build_naml_kernel.bat`**. It:
1. Checks for WSL (Windows Subsystem for Linux). If WSL isn't installed,
   it stops and tells you exactly how to install it (`wsl --install` from
   an admin PowerShell, then one manual first-run of Ubuntu to set a Linux
   username/password).
2. If WSL is present, opens a `cmd` window and runs the real build
   (`build_naml_kernel.sh`) inside it, live, so you see every step.
3. Keeps the window open at the end (success or failure) so you can read
   the output — it does not close itself.

### On Linux / macOS-with-a-Linux-VM
Open a terminal in this folder and run `./build_naml_kernel.sh` directly
(a kernel cannot be cross-built from macOS without a Linux environment of
some kind — WSL serves the same role on Windows).

## What the script actually does (no hidden steps)
1. Installs build dependencies via `apt-get` if available (asks for your
   `sudo` password) — `build-essential bc bison flex libssl-dev libelf-dev
   gcc-multilib libc6-dev-i386 wget tar xz-utils patch`. On a non-apt
   distro, install the equivalents yourself first and set `SKIP_APT=1`.
2. Downloads a real kernel tarball from `cdn.kernel.org` (default version
   set in the script — **check <https://kernel.org> for the current
   longterm version and override with `KERNEL_VERSION=x.y.z` if this
   default has gone stale**; longterm releases get new point versions
   regularly).
3. Extracts it, and tries to apply this repo's `kernel/patches/*.patch`.
4. Copies `naml_defconfig` in as `.config` and runs `make ARCH=i386
   olddefconfig` to port it onto that kernel version.
5. Builds with `make ARCH=i386 -j<nproc>` (32-bit, via `gcc-multilib` on a
   64-bit host — no separate cross-compiler needed on a Debian/Ubuntu-
   family system).
6. Copies the resulting `arch/x86/boot/bzImage` to
   `output/vmlinuz-naml-<version>`.

## Read this before you run it — things that are expected, not bugs

- **This has not been run end-to-end by whoever wrote it.** The
  environment this script was written in has no internet access and no
  kernel build toolchain, so only the script's *logic* was tested (with
  fake `wget`/`tar`/`patch`/`make` standing in, to check it takes the
  right branches and produces the right paths/messages) — never a real
  download or a real compile. Watch the actual output; don't assume a
  clean exit means a working kernel without looking.
- **The patches will very likely be skipped, and that's fine.**
  `kernel/patches/*.patch` in this repo are explicitly labeled by their
  own header comments as "illustrative ... rebase it against the selected
  kernel version" — they are placeholders, not verified-working patches
  against any specific real kernel tree. The script tries each one with a
  dry run first and skips (with a clear message), not fails, anything
  that doesn't apply cleanly. The kernel still builds and boots without
  them — they only add a cosmetic boot banner string and similar, nothing
  anything else in NAML depends on.
- **`naml_defconfig` is old-style and may have aged options.**
  `make ARCH=i386 olddefconfig` fills in anything missing with the new
  kernel's defaults and reports (without failing) any option
  `naml_defconfig` sets that no longer exists on a very recent kernel.
  Some legacy per-CPU options (`CONFIG_M686` and similar, for the
  Pentium-4-era target this project describes) may have been renamed or
  removed on newer kernel versions — if the build output flags that,
  either pick an older `KERNEL_VERSION` (closer to the kernel generation
  this config was written against) or adjust `.config` by hand (`make
  ARCH=i386 menuconfig`) before continuing from the build step.
- **Time and disk.** Expect several hundred MB downloaded and a few GB of
  free disk for the extracted source + build output, and anywhere from
  ~15 minutes to well over an hour to compile, depending on your machine
  and `JOBS`.

## After it succeeds
You'll have `output/vmlinuz-naml-<version>` — a real, bootable-for-x86
Linux kernel image. That is one piece of what `docs/SPEC.md` §4 describes,
not the whole bootable NAML ISO. To go further (initramfs, SquashFS root,
bootloader, a `qemu-system-i386` smoke test), use the main NAML repo's own
`build/mkinitramfs.py` and `build/mkiso.sh` — point the latter at this
output with `KERNEL=output/vmlinuz-naml-<version> ./build/mkiso.sh`. That
is a separate, not-yet-finished piece of tooling in this project; see its
own `docs/KNOWN_ISSUES.md`.

## Overriding defaults
```
KERNEL_VERSION=6.12.107 WORK_DIR=/tmp/naml-kbuild OUT_DIR=/tmp/naml-out \
JOBS=8 ./build_naml_kernel.sh
```
